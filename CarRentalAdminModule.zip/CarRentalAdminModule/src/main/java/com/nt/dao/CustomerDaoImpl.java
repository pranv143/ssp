package com.nt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.nt.bo.CustomerBo;
import com.nt.connection.GetConnectionPool;
import com.nt.controller.DeleteController;

public class CustomerDaoImpl implements CustomerDao {

	final static String  UPDATE_QUERY="UPDATE CUSTOMERREG SET PERMISSION=? WHERE SNO=?";
	final static String  DELETE_QUERY="DELETE FROM CUSTOMERREG WHERE SNO=?";


	


	@Override
	public int givePermission(CustomerBo bo) throws Exception {
		
		
		Connection con=null;
		PreparedStatement ps=null;
		int count=0;
		//get Pooled Connection
		con=GetConnectionPool.getPooledConnection();
		//create PreparedStatement obj
		ps=con.prepareStatement(UPDATE_QUERY);
		//set values to Query params
		
		ps.setInt(1, bo.getPermission());
		ps.setInt(2, bo.getCid());
		
		
				//execute theQuery
				count=ps.executeUpdate();
				//close jdbc objs
				ps.close();
				con.close();
				return count;
	}

	@Override
	public int deleteOperation(int sno) throws Exception {

		
		Connection con=null;
		PreparedStatement ps=null;
		int count=0;
		//get Pooled Connection
		con=GetConnectionPool.getPooledConnection();
		//create PreparedStatement obj
		ps=con.prepareStatement(DELETE_QUERY);
		//set values to Query params
		
		ps.setInt(1,sno);
		
		
		//execute theQuery
		count=ps.executeUpdate();
		//close jdbc objs
		ps.close();
		con.close();
		return count;
	}

}
