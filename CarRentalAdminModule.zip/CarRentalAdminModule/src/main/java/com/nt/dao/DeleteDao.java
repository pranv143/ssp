package com.nt.dao;

public interface DeleteDao {
	
	public int deleteOperation()throws Exception;

}
