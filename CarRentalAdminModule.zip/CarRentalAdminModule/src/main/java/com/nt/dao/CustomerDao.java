package com.nt.dao;

import com.nt.bo.CustomerBo;

public interface CustomerDao {
	
	public int givePermission(CustomerBo bo)throws Exception;
	public int deleteOperation(int sno)throws Exception;
	
	

}
