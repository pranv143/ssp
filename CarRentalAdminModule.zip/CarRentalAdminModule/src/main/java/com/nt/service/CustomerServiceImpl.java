package com.nt.service;

import com.nt.bo.CustomerBo;
import com.nt.dao.CustomerDao;
import com.nt.dao.CustomerDaoImpl;
import com.nt.dto.CustomerDto;

public class CustomerServiceImpl implements CustomerService {
	private CustomerDao dao;
	

	

	@Override
	public String givePermission(CustomerDto dto) throws Exception {
		
		CustomerBo bo=null;
		int count=0;
		dao=new CustomerDaoImpl();
        bo=new CustomerBo();
        
        bo.setPermission(dto.getPermission());
        bo.setCid(dto.getCid());
        
      //use DAO 
        count=dao.givePermission(bo);
        //process the Reuslts
        if(count==0)
        	 return "Permission Failed---> ";
        else
        	 return "Successfully Given Permission--->";
		
	}




	@Override
	public String deleteOperation(int sno) throws Exception {
		int count=0;
		dao=new CustomerDaoImpl();
		
		//use DAO 
        count=dao.deleteOperation(sno);
        //process the Reuslts
        if(count==0)
        	 return "Customer deleting Failed---> ";
        else
        	 return "Customer deleting Succeded--->";	}

}//class
