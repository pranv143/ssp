package com.nt.service;

import com.nt.dto.CustomerDto;


public interface CustomerService {
	
	public   String   givePermission(CustomerDto dto)throws Exception;
	public String deleteOperation(int b)throws Exception;
	


}
