package com.nt.dto;

import java.io.Serializable;

import lombok.Data;
@Data
public class CustomerDto implements Serializable {
	private static final long serialVersionUID = 1L;
	
	
	private int permission;
	private int cid;
}
