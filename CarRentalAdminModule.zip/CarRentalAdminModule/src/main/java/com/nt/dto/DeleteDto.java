package com.nt.dto;

import java.io.Serializable;

import lombok.Data;
@Data
public class DeleteDto implements Serializable {
	
	private int sno;

}
