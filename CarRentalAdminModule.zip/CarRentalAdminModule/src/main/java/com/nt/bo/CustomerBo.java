package com.nt.bo;

import lombok.Data;

@Data
public class CustomerBo {
	private int permission;
	private int cid;
	
	
	
}
